/**
 * THEME SWITCHER
 * Dark/Light Mode Toggle Functionality
 */

document.addEventListener("DOMContentLoaded", function () {
  const themeToggle = document.getElementById("themeToggle");
  const htmlElement = document.documentElement;

  // Check for saved theme preference or use preferred color scheme
  const savedTheme = localStorage.getItem("theme");
  const prefersDarkScheme = window.matchMedia("(prefers-color-scheme: dark)");

  // Set initial theme
  if (savedTheme) {
    htmlElement.setAttribute("data-theme", savedTheme);
  } else if (prefersDarkScheme.matches) {
    htmlElement.setAttribute("data-theme", "dark");
  } else {
    htmlElement.setAttribute("data-theme", "light");
  }

  // Theme toggle functionality
  if (themeToggle) {
    themeToggle.addEventListener("click", function () {
      const currentTheme = htmlElement.getAttribute("data-theme");
      const newTheme = currentTheme === "dark" ? "light" : "dark";

      // Apply new theme
      htmlElement.setAttribute("data-theme", newTheme);

      // Save preference to localStorage
      localStorage.setItem("theme", newTheme);

      // Add animation class for smooth transition
      document.body.classList.add("theme-transition");

      // Remove animation class after transition
      setTimeout(() => {
        document.body.classList.remove("theme-transition");
      }, 300);

      // Dispatch custom event for other components to listen to
      const themeChangeEvent = new CustomEvent("themeChange", {
        detail: { theme: newTheme },
      });
      window.dispatchEvent(themeChangeEvent);

      // Log for debugging
      console.log(`Theme changed to: ${newTheme}`);
    });

    // Add keyboard accessibility
    themeToggle.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        this.click();
      }
    });
  }

  // Listen for system theme changes
  prefersDarkScheme.addEventListener("change", function (e) {
    // Only update if user hasn't set a preference
    if (!localStorage.getItem("theme")) {
      const newTheme = e.matches ? "dark" : "light";
      htmlElement.setAttribute("data-theme", newTheme);

      // Dispatch theme change event
      const themeChangeEvent = new CustomEvent("themeChange", {
        detail: { theme: newTheme },
      });
      window.dispatchEvent(themeChangeEvent);
    }
  });

  // Function to get current theme
  window.getCurrentTheme = function () {
    return htmlElement.getAttribute("data-theme");
  };

  // Function to set theme programmatically
  window.setTheme = function (theme) {
    if (theme === "dark" || theme === "light") {
      htmlElement.setAttribute("data-theme", theme);
      localStorage.setItem("theme", theme);

      // Dispatch theme change event
      const themeChangeEvent = new CustomEvent("themeChange", {
        detail: { theme },
      });
      window.dispatchEvent(themeChangeEvent);

      return true;
    }
    return false;
  };

  // Initialize with console message
  console.log(`Theme initialized: ${htmlElement.getAttribute("data-theme")}`);
});
