/**
 * NEXUS DIGITAL AGENCY - MAIN JAVASCRIPT
 * Premium functionality for the website
 */

// Wait for DOM to be fully loaded
document.addEventListener("DOMContentLoaded", function () {
  // Initialize all components
  initPreloader();
  initNavigation();
  initAnimations();
  initCounters();
  initPortfolioFilter();
  initTestimonialSlider();
  initVideoPlayer();
  initAudioPlayer();
  initGallery();
  initFAQ();
  initContactForm();
  initNewsletter();

  // Initialize theme switcher (separate file will handle this)
  console.log("Nexus Digital Agency - Premium Website Initialized");
});

/**
 * Preloader
 */
function initPreloader() {
  const preloader = document.querySelector(".preloader");

  if (preloader) {
    // Hide preloader when page is fully loaded
    window.addEventListener("load", function () {
      setTimeout(function () {
        preloader.classList.add("loaded");

        // Remove preloader from DOM after animation
        setTimeout(function () {
          preloader.style.display = "none";
        }, 500);
      }, 500);
    });
  }
}

/**
 * Navigation
 */
function initNavigation() {
  const navbar = document.querySelector(".navbar");
  const menuToggle = document.querySelector(".menu-toggle");
  const navMenu = document.querySelector(".nav-menu");
  const navLinks = document.querySelectorAll(".nav-link");

  // Navbar scroll effect
  window.addEventListener("scroll", function () {
    if (window.scrollY > 50) {
      navbar.classList.add("scrolled");
    } else {
      navbar.classList.remove("scrolled");
    }
  });

  // Mobile menu toggle
  if (menuToggle && navMenu) {
    menuToggle.addEventListener("click", function () {
      menuToggle.classList.toggle("active");
      navMenu.classList.toggle("active");

      // Toggle body scroll when menu is open
      if (navMenu.classList.contains("active")) {
        document.body.style.overflow = "hidden";
      } else {
        document.body.style.overflow = "";
      }
    });

    // Close menu when clicking on a link
    navLinks.forEach((link) => {
      link.addEventListener("click", function () {
        menuToggle.classList.remove("active");
        navMenu.classList.remove("active");
        document.body.style.overflow = "";
      });
    });

    // Close menu when clicking outside
    document.addEventListener("click", function (event) {
      if (
        !navMenu.contains(event.target) &&
        !menuToggle.contains(event.target) &&
        navMenu.classList.contains("active")
      ) {
        menuToggle.classList.remove("active");
        navMenu.classList.remove("active");
        document.body.style.overflow = "";
      }
    });
  }

  // Active navigation link based on current page
  const currentPage = window.location.pathname.split("/").pop() || "index.html";

  navLinks.forEach((link) => {
    const linkHref = link.getAttribute("href");

    if (
      linkHref === currentPage ||
      (currentPage === "" && linkHref === "index.html")
    ) {
      link.classList.add("active");
    } else {
      link.classList.remove("active");
    }
  });
}

/**
 * Scroll Animations
 */
function initAnimations() {
  // Create Intersection Observer for scroll animations
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  };

  const observer = new IntersectionObserver(function (entries) {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("active");
      }
    });
  }, observerOptions);

  // Observe elements with animation classes
  const animatedElements = document.querySelectorAll(
    ".fade-in, .slide-in-left, .slide-in-right, .scale-in"
  );

  animatedElements.forEach((element) => {
    observer.observe(element);
  });

  // Check for elements already in viewport on page load
  animatedElements.forEach((element) => {
    const rect = element.getBoundingClientRect();
    const isVisible =
      rect.top <=
        (window.innerHeight || document.documentElement.clientHeight) &&
      rect.bottom >= 0;

    if (isVisible) {
      element.classList.add("active");
    }
  });

  // Parallax effect for hero section
  window.addEventListener("scroll", function () {
    const scrolled = window.pageYOffset;
    const parallaxElements = document.querySelectorAll(".floating-card");

    parallaxElements.forEach((element, index) => {
      const speed = 0.1 + index * 0.05;
      const yPos = -(scrolled * speed);
      element.style.transform = `translateY(${yPos}px)`;
    });
  });
}

/**
 * Animated Counters
 */
function initCounters() {
  const counters = document.querySelectorAll(".stat-number");

  if (counters.length > 0) {
    // Create observer for counters
    const counterObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const counter = entry.target;
            const target = parseInt(counter.getAttribute("data-count"));
            const duration = 2000; // 2 seconds
            const increment = target / (duration / 16); // 60fps
            let current = 0;

            const updateCounter = () => {
              current += increment;

              if (current < target) {
                counter.textContent = Math.floor(current);
                requestAnimationFrame(updateCounter);
              } else {
                counter.textContent = target;
              }
            };

            updateCounter();

            // Stop observing after animation starts
            counterObserver.unobserve(counter);
          }
        });
      },
      { threshold: 0.5 }
    );

    // Observe each counter
    counters.forEach((counter) => {
      counterObserver.observe(counter);
    });
  }
}

/**
 * Portfolio Filter
 */
function initPortfolioFilter() {
  const filterButtons = document.querySelectorAll(".filter-btn");
  const portfolioItems = document.querySelectorAll(".portfolio-item");

  if (filterButtons.length > 0 && portfolioItems.length > 0) {
    filterButtons.forEach((button) => {
      button.addEventListener("click", function () {
        // Remove active class from all buttons
        filterButtons.forEach((btn) => btn.classList.remove("active"));

        // Add active class to clicked button
        this.classList.add("active");

        // Get filter value
        const filterValue = this.getAttribute("data-filter");

        // Show/hide portfolio items
        portfolioItems.forEach((item) => {
          const categories = item.getAttribute("data-category");

          if (filterValue === "all" || categories.includes(filterValue)) {
            item.style.display = "block";

            // Add animation
            setTimeout(() => {
              item.style.opacity = "1";
              item.style.transform = "translateY(0)";
            }, 10);
          } else {
            item.style.opacity = "0";
            item.style.transform = "translateY(20px)";

            setTimeout(() => {
              item.style.display = "none";
            }, 300);
          }
        });
      });
    });

    // Load more button functionality
    const loadMoreBtn = document.getElementById("loadMore");

    if (loadMoreBtn) {
      loadMoreBtn.addEventListener("click", function () {
        // In a real implementation, this would load more items from an API
        // For demo purposes, we'll just show a message
        this.innerHTML = "<span>No More Projects</span>";
        this.disabled = true;
        this.classList.add("disabled");

        // Show notification
        showNotification("All projects loaded successfully!", "success");
      });
    }
  }
}

/**
 * Testimonial Slider
 */
function initTestimonialSlider() {
  const testimonialTrack = document.querySelector(".testimonial-track");
  const testimonialSlides = document.querySelectorAll(".testimonial-slide");
  const prevBtn = document.querySelector(".testimonial-prev");
  const nextBtn = document.querySelector(".testimonial-next");

  if (testimonialTrack && testimonialSlides.length > 0) {
    let currentSlide = 0;
    const slideCount = testimonialSlides.length;

    // Set initial position
    updateSliderPosition();

    // Next button
    if (nextBtn) {
      nextBtn.addEventListener("click", function () {
        currentSlide = (currentSlide + 1) % slideCount;
        updateSliderPosition();
      });
    }

    // Previous button
    if (prevBtn) {
      prevBtn.addEventListener("click", function () {
        currentSlide = (currentSlide - 1 + slideCount) % slideCount;
        updateSliderPosition();
      });
    }

    // Auto slide every 5 seconds
    setInterval(function () {
      currentSlide = (currentSlide + 1) % slideCount;
      updateSliderPosition();
    }, 5000);

    function updateSliderPosition() {
      testimonialTrack.style.transform = `translateX(-${currentSlide * 100}%)`;

      // Update active state for dots (if we had dots)
      // This would be implemented if we add dot indicators
    }
  }
}

/**
 * Video Player
 */
function initVideoPlayer() {
  const videoPlayers = document.querySelectorAll("video");
  const videoPlayButtons = document.querySelectorAll(
    ".video-play, .video-play-small"
  );

  if (videoPlayers.length > 0) {
    videoPlayButtons.forEach((button) => {
      button.addEventListener("click", function () {
        const videoContainer = this.closest(".video-container");
        const video = videoContainer
          ? videoContainer.querySelector("video")
          : null;

        if (video) {
          if (video.paused) {
            video.play();
            this.innerHTML = '<i class="fas fa-pause"></i>';
          } else {
            video.pause();
            this.innerHTML = '<i class="fas fa-play"></i>';
          }
        }
      });
    });

    // Update play button when video is played/paused
    videoPlayers.forEach((video) => {
      video.addEventListener("play", function () {
        const playButton =
          this.closest(".video-container")?.querySelector(".video-play");
        if (playButton) {
          playButton.innerHTML = '<i class="fas fa-pause"></i>';
        }
      });

      video.addEventListener("pause", function () {
        const playButton =
          this.closest(".video-container")?.querySelector(".video-play");
        if (playButton) {
          playButton.innerHTML = '<i class="fas fa-play"></i>';
        }
      });
    });
  }
}

/**
 * Audio Player
 */
function initAudioPlayer() {
  const audioPlayers = document.querySelectorAll("audio");
  const episodePlayButtons = document.querySelectorAll(".episode-play");

  if (audioPlayers.length > 0) {
    // Main audio player controls
    const mainAudio = document.getElementById("mainAudio");

    if (mainAudio) {
      mainAudio.addEventListener("play", function () {
        console.log("Audio started playing");
      });

      mainAudio.addEventListener("ended", function () {
        console.log("Audio finished playing");
      });
    }

    // Episode play buttons
    episodePlayButtons.forEach((button) => {
      button.addEventListener("click", function () {
        const episodeNumber =
          this.closest(".episode-item").querySelector(
            ".episode-number"
          ).textContent;

        // In a real implementation, this would load different audio files
        // For demo, we'll just show a notification
        showNotification(`Playing Episode ${episodeNumber}`, "info");

        // Change button icon
        const icon = this.querySelector("i");
        if (icon.classList.contains("fa-play")) {
          icon.classList.remove("fa-play");
          icon.classList.add("fa-pause");
        } else {
          icon.classList.remove("fa-pause");
          icon.classList.add("fa-play");
        }
      });
    });
  }
}

/**
 * Gallery
 */
function initGallery() {
  const galleryItems = document.querySelectorAll(".gallery-item");

  if (galleryItems.length > 0) {
    galleryItems.forEach((item) => {
      item.addEventListener("click", function () {
        // In a real implementation, this would open a lightbox
        // For demo, we'll just add a visual effect
        this.classList.toggle("zoomed");

        if (this.classList.contains("zoomed")) {
          this.style.transform = "scale(1.05)";
          this.style.zIndex = "10";
        } else {
          this.style.transform = "";
          this.style.zIndex = "";
        }
      });
    });
  }
}

/**
 * FAQ Accordion
 */
function initFAQ() {
  const faqQuestions = document.querySelectorAll(".faq-question");

  if (faqQuestions.length > 0) {
    faqQuestions.forEach((question) => {
      question.addEventListener("click", function () {
        const faqItem = this.closest(".faq-item");
        const isActive = faqItem.classList.contains("active");

        // Close all FAQ items
        document.querySelectorAll(".faq-item").forEach((item) => {
          item.classList.remove("active");
        });

        // Open clicked item if it wasn't active
        if (!isActive) {
          faqItem.classList.add("active");
        }
      });
    });

    // Open first FAQ item by default
    if (faqQuestions.length > 0) {
      faqQuestions[0].closest(".faq-item").classList.add("active");
    }
  }
}

/**
 * Contact Form
 */
function initContactForm() {
  const contactForm = document.getElementById("contactForm");

  if (contactForm) {
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault();

      // Get form data
      const formData = new FormData(this);
      const name = formData.get("name");
      const email = formData.get("email");
      const message = formData.get("message");

      // Simple validation
      let isValid = true;
      const errors = {};

      // Validate name
      if (!name || name.trim().length < 2) {
        isValid = false;
        errors.name = "Name must be at least 2 characters";
      }

      // Validate email
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!email || !emailRegex.test(email)) {
        isValid = false;
        errors.email = "Please enter a valid email address";
      }

      // Validate message
      if (!message || message.trim().length < 10) {
        isValid = false;
        errors.message = "Message must be at least 10 characters";
      }

      // Display errors or submit form
      if (!isValid) {
        // Show error messages
        Object.keys(errors).forEach((field) => {
          const errorElement = document.getElementById(`${field}Error`);
          if (errorElement) {
            errorElement.textContent = errors[field];
            errorElement.style.display = "block";
          }
        });

        showNotification("Please fix the errors in the form", "error");
      } else {
        // Clear error messages
        document.querySelectorAll(".error-message").forEach((el) => {
          el.textContent = "";
          el.style.display = "none";
        });

        // Show success message
        const formMessage = document.getElementById("formMessage");
        if (formMessage) {
          formMessage.textContent =
            "Thank you! Your message has been sent successfully.";
          formMessage.className = "form-message success";
          formMessage.style.display = "block";
        }

        // Reset form
        contactForm.reset();

        // Hide success message after 5 seconds
        setTimeout(() => {
          if (formMessage) {
            formMessage.style.display = "none";
          }
        }, 5000);

        // In a real implementation, you would send the form data to a server here
        console.log("Form submitted with data:", {
          name,
          email,
          phone: formData.get("phone"),
          service: formData.get("service"),
          message,
        });
      }
    });

    // Clear error messages on input
    const formInputs = contactForm.querySelectorAll("input, textarea, select");
    formInputs.forEach((input) => {
      input.addEventListener("input", function () {
        const fieldName = this.name;
        const errorElement = document.getElementById(`${fieldName}Error`);

        if (errorElement) {
          errorElement.textContent = "";
          errorElement.style.display = "none";
        }
      });
    });
  }
}

/**
 * Newsletter Form
 */
function initNewsletter() {
  const newsletterForm = document.querySelector(".newsletter-form");

  if (newsletterForm) {
    newsletterForm.addEventListener("submit", function (e) {
      e.preventDefault();

      const emailInput = this.querySelector('input[type="email"]');
      const email = emailInput.value.trim();

      // Simple validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (!email || !emailRegex.test(email)) {
        showNotification("Please enter a valid email address", "error");
        emailInput.focus();
        return;
      }

      // Show success message
      showNotification(
        "Thank you for subscribing to our newsletter!",
        "success"
      );

      // Reset form
      this.reset();

      // In a real implementation, you would send the email to a server here
      console.log("Newsletter subscription:", email);
    });
  }
}

/**
 * Utility: Show Notification
 */
function showNotification(message, type = "info") {
  // Create notification element
  const notification = document.createElement("div");
  notification.className = `notification notification-${type}`;
  notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${
              type === "success"
                ? "check-circle"
                : type === "error"
                ? "exclamation-circle"
                : "info-circle"
            }"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close">
            <i class="fas fa-times"></i>
        </button>
    `;

  // Add styles if not already added
  if (!document.querySelector("#notification-styles")) {
    const styles = document.createElement("style");
    styles.id = "notification-styles";
    styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: var(--bg-card);
                border: 1px solid var(--border-color);
                border-radius: var(--radius-lg);
                padding: 1rem 1.5rem;
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 1rem;
                max-width: 400px;
                box-shadow: var(--shadow-xl);
                z-index: 9999;
                transform: translateX(120%);
                transition: transform 0.3s ease;
            }
            
            .notification.show {
                transform: translateX(0);
            }
            
            .notification-success {
                border-left: 4px solid #10b981;
            }
            
            .notification-error {
                border-left: 4px solid #f87171;
            }
            
            .notification-info {
                border-left: 4px solid #3b82f6;
            }
            
            .notification-content {
                display: flex;
                align-items: center;
                gap: 0.75rem;
            }
            
            .notification-content i {
                font-size: 1.25rem;
            }
            
            .notification-success .notification-content i {
                color: #10b981;
            }
            
            .notification-error .notification-content i {
                color: #f87171;
            }
            
            .notification-info .notification-content i {
                color: #3b82f6;
            }
            
            .notification-close {
                background: none;
                border: none;
                color: var(--text-tertiary);
                cursor: pointer;
                padding: 0.25rem;
                border-radius: var(--radius-sm);
                transition: var(--transition-base);
            }
            
            .notification-close:hover {
                background: rgba(255, 255, 255, 0.1);
                color: var(--text-primary);
            }
        `;
    document.head.appendChild(styles);
  }

  // Add to page
  document.body.appendChild(notification);

  // Show notification
  setTimeout(() => {
    notification.classList.add("show");
  }, 10);

  // Close button
  const closeButton = notification.querySelector(".notification-close");
  closeButton.addEventListener("click", function () {
    notification.classList.remove("show");
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 300);
  });

  // Auto-remove after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.classList.remove("show");
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }
  }, 5000);
}

/**
 * Smooth scrolling for anchor links
 */
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    const href = this.getAttribute("href");

    // Only handle internal anchor links
    if (href !== "#" && href.startsWith("#")) {
      e.preventDefault();

      const targetId = href.substring(1);
      const targetElement = document.getElementById(targetId);

      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 80,
          behavior: "smooth",
        });
      }
    }
  });
});
